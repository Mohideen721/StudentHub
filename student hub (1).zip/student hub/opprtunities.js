let products = {
    data: [
      {
        CompanyName: "Infosys",
        category: "Service",
        type:"Job",
        location:"Bengaluru" ,
        Salary: "6 LPA",
        Role:"Data Analyst",
        link:"https://career.infosys.com/joblist"
      },
      {
        CompanyName: "Amazon",
        category: "Product",
        type:"Internship",
        location:"Bengaluru" ,
        Salary: "20,000 per month",
        Role:"SDE",
        link:"https://www.amazon.jobs/en/"
      },
      {
        CompanyName: "WIPRO",
        category: "Service",
        type:"Job",
        location:"Chennai" ,
        Salary: "3 LPA",
        Role:"System Engineer",
        link:"www.google.com"
      },
      {
        CompanyName: "TCS",
        category: "Service",
        type:"Job",
        location:"Hyderabad" ,
        Salary: "4 LPA",
        Role:"Digital Specialist Engineer",
        link:"https://career.infosys.com/joblist"
      },
      {
        CompanyName: "Salesforce",
        category: "Product",
        type:"Internship",
        location:"Bengaluru" ,
        Salary: "10000 per month",
        Role:"Data Engineer",
        link:"https://career.infosys.com/joblist"
      },
      {
        CompanyName: "Cognizant",
        category: "Service",
        type:"Job",
        location:"Chennai" ,
        Salary: "5 LPA",
        Role:"System Engineer",
        link:"https://career.infosys.com/joblist"
      },
      {
        CompanyName: "Zoho Corporation",
        category: "Product",
        type:"Job",
        location:"Hyderabad" ,
        Salary: "7 LPA",
        Role:"Data Analyst",
        link:"https://career.infosys.com/joblist"
      },
      {
        CompanyName: "Accenture",
        category: "Service",
        type:"Internship",
        location:"Hyderabad" ,
        Salary: "20000 per month",
        Role:"SDE",
        link:"https://career.infosys.com/joblist"
      },
      {
        CompanyName: "Amazon",
        category: "Product",
        type:"Job",
        location:"" ,
        Salary: "7 LPA",
        Role:"Data Analyst",
        link:"https://career.infosys.com/joblist"
      },
      {
        CompanyName: "Accolite",
        category: "Product",
        type:"Internship",
        location:"Hyderabad" ,
        Salary: "4 LPA",
        Role:"Software Developer",
        link:"https://career.infosys.com/joblist"
      },
      {
        CompanyName: "Adobe",
        category: "Product",
        type:"Internship",
        location:"Chennai" ,
        Salary: "30000 per month",
        Role:"Data Engineer",
        link:"https://career.infosys.com/joblist"
      },
      {
        CompanyName: "Zerodha",
        category: "Product",
        type:"Job",
        location:"Bengaluru" ,
        Salary: "7 LPA",
        Role:"Data Analyst",
        link:"https://career.infosys.com/joblist"
      },
      {
        CompanyName: "MuSigma",
        category: "Service",
        type:"Job",
        location:"Hyderabad" ,
        Salary: "3 LPA",
        Role:"System Engineer",
        link:"https://career.infosys.com/joblist"
      },
      {
        CompanyName: "ServiceNow",
        category: "Product",
        type:"Internship",
        location:"Chennai" ,
        Salary: "50000 per month",
        Role:"SDE",
        link:"https://career.infosys.com/joblist"
      },
      {
        CompanyName: "Microsoft",
        category: "Product",
        type:"Internship",
        location:"Hyderabad" ,
        Salary: "30000 per month",
        Role:"Developer",
        link:"https://career.infosys.com/joblist"
      },
      {
        CompanyName: "RedShift",
        category: "Product",
        type:"Job",
        location:"Hyderabad" ,
        Salary: "7 LPA",
        Role:"Data Analyst",
        link:"https://career.infosys.com/joblist"
      },
      {
        CompanyName: "Think School",
        category: "Product",
        type:"Job",
        location:"Hyderabad" ,
        Salary: "3 LPA",
        Role:"Data Analyst",
        link:"https://career.infosys.com/joblist"
      },
      {
        CompanyName: "Byjus",
        category: "Product",
        type:"Job",
        location:"Chennai" ,
        Salary: "7 LPA",
        Role:"Product Manager",
        link:"https://career.infosys.com/joblist"
      },
      {
        CompanyName: "Tata Steel",
        category: "Product",
        type:"Job",
        location:"Bengaluru" ,
        Salary: "10 LPA",
        Role:"Quality Spealist",
        link:"https://career.infosys.com/joblist"
      },
      {
        CompanyName: "Apsire Infotech ",
        category: "Product",
        type:"Internship",
        location:"Hyderabad" ,
        Salary: "7 LPA",
        Role:"Data Analyst",
        link:"https://career.infosys.com/joblist"
      },
      {
        CompanyName: "Cisco",
        category: "Product",
        type:"Internship",
        location:"Hyderabad" ,
        Salary: "20000 per month",
        Role:"SDE-I",
        link:"https://career.infosys.com/joblist"
      },
      {
        CompanyName: "Google",
        category: "Product",
        type:"Job",
        location:"Hyderabad" ,
        Salary: "40 LPA",
        Role:"SDE-II",
        link:"https://career.infosys.com/joblist"
      },
      {
        CompanyName: "Intel",
        category: "Product",
        type:"Internship",
        location:"Bengaluru" ,
        Salary: "40000 per month",
        Role:"SDE",
        link:"https://career.infosys.com/joblist"
      },
      {
        CompanyName: "Intuit",
        category: "Product",
        type:"Job",
        location:"Chennai" ,
        Salary: "10 LPA",
        Role:"Data Engineer",
        link:"https://career.infosys.com/joblist"
      },
    ],
  };
  
  for (let i of products.data) {
    //Create Card
    let card = document.createElement("div");
    //Card should have category and should stay hidden initially
    card.classList.add("card", i.category, "hide");
    //image div
    //let imgContainer = document.createElement("div");
    //imgContainer.classList.add("image-container");
    //img tag
    //let image = document.createElement("img");
    //image.setAttribute("src", i.image);
    //imgContainer.appendChild(image);
    //card.appendChild(imgContainer);
    //container
    let container = document.createElement("div");
    container.classList.add("container");
    //product name
    let name = document.createElement("h8");
    name.style.fontFamily = 'Arial, sans-serif';
    name.style.fontSize = '16px';
    name.style.fontWeight = 'bold';  
    name.classList.add("company-name");
    name.innerText = i.CompanyName.toUpperCase();
    container.appendChild(name);
    //category
    let cat = document.createElement("h6");
    cat.innerText =i.category;
    container.appendChild(cat);
    //type
    let type = document.createElement("h6");
    type.innerText = i.type;
    container.appendChild(type);
    //location
    let loc = document.createElement("h6");
    loc.innerText = i.location;
    container.appendChild(loc);
    //salary
    let sal = document.createElement("h6");
    sal.innerText = i.Salary;
    container.appendChild(sal);
    //button
    let button1=document.createElement("button")
    const url= i.link;
    button1.textContent = 'Apply';
    button1.style.backgroundColor = 'blue';
    button1.style.color = 'white';
    button1.style.padding = '10px';  
    button1.style.borderRadius = '5px';
    container.appendChild(button1);
    button1.onclick = function() {
      window.location.replace(url);
    };
  
    card.appendChild(container);
    document.getElementById("products").appendChild(card);
  }
  
  //parameter passed from button (Parameter same as category)
  function filterProduct(value){
    //Button class code
    let buttons = document.querySelectorAll(".button-value");
    buttons.forEach((button) => {
      //check if value equals innerText
      if (value.toUpperCase() == button.innerText.toUpperCase()) {
        button.classList.add("active");
      } else {
        button.classList.remove("active");
      }
    });
  
    //select all cards
    let elements = document.querySelectorAll(".card");
    //loop through all cards
    elements.forEach((element) => {
      //display all cards on 'all' button click
      if (value == "all") {
        element.classList.remove("hide");
      } else{
        //Check if element contains category class
        if (element.classList.contains(value)) {
          //display element based on category
          element.classList.remove("hide");
        } else {
          //hide other elements
          element.classList.add("hide");
        }
      }
    });
  
  //Search button click
  //document.getElementById("search").addEventListener("click", () => {
    //initializations
    //let searchInput = document.getElementById("search-input").value;
    //let elements = document.querySelectorAll(".product-name");
    //let cards = document.querySelectorAll(".card");
  
    //loop through all elements
    //elements.forEach((element, index) => {
      //check if text includes the search value
      //if (element.innerText.includes(searchInput.toUpperCase())) {
        //display matching card
        //cards[index].classList.remove("hide");
      //} else {
        //hide others
        //cards[index].classList.add("hide");
      //}
    //});
  //});
  
  //Initially display all products
  window.onload = () => {
    filterProduct("all");
  };}