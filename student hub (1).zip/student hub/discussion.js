  const chatBox = document.getElementById('chat-box');
const chatInput = document.getElementById('chat-input');
const sendBtn = document.getElementById('send-btn');

sendBtn.addEventListener('click', () => {
  const message = chatInput.value;
  if (message.trim() !== '') {
    sendMessage('user', message);
    getResponse(message);
    chatInput.value = '';
  }
});

function sendMessage(sender, message) {
  const div = document.createElement('div');
  div.classList.add('message', sender);
  div.innerHTML = `<p>${message}</p>`;
  chatBox.appendChild(div);
  chatBox.scrollTop = chatBox.scrollHeight;
}

function getResponse(message) {
  // You can replace this function with your own API call or custom logic
  const responses = [
    'Hello! How can I help you?',
    'I\'m sorry, I didn\'t understand that.',
    'Can you please be more specific?',
    'Sure, I can help you with that.',
    'Thanks for reaching out to me!',
    'I\'m glad you asked!',
    'Let me see if I can find an answer for you.',
    'I need more information to help you with that.',
    'That\'s a great question!',
    'I\'m here to help you!',
  ];
  const randomIndex = Math.floor(Math.random() * responses.length);
  const response = responses[randomIndex];
  sendMessage('bot', response);
}
