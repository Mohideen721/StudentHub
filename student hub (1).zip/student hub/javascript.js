const categories = document.querySelectorAll(".category");
const rightPaneHeading = document.getElementById("right-pane-heading");

categories.forEach(function(category) {
  category.addEventListener("click", function() {
    const categoryName = category.getAttribute("data-name");
    rightPaneHeading.textContent = categoryName + " Resources";
  });
});



