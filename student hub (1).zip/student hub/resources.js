const categories = document.querySelectorAll(".category");
const rightPaneHeading = document.getElementById("right-pane-heading");

categories.forEach(function(category) {
  category.addEventListener("click", function() {
    const categoryName = category.getAttribute("data-name");
    rightPaneHeading.textContent = categoryName + " Resources";
  });
});
const shareBtn = document.getElementById('add-resource-btn');
const shareForm = document.getElementById('share-form');

shareBtn.addEventListener('click', () => {
  if (shareForm.style.display === 'none') {
    shareForm.style.display = 'block';
  } else {
    shareForm.style.display = 'none';
  }
});